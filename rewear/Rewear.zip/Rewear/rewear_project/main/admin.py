from django.contrib import admin
# from .models import ToDoList, Item
# from .models import HostingPlace, GuideInfo
from main.models import market
# Register your models here.
# admin.site.register(ToDoList)
# admin.site.register(Item)
admin.site.register(market)
# admin.site.register(HostingPlace)
# admin.site.register(GuideInfo)